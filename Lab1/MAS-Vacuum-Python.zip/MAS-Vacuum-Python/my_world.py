from base import Agent, Action, Perception
from representation import GridRelativeOrientation, GridOrientation
from gridworld import AbstractGridEnvironment, GridAgentData
from enum import Enum

import time

class MyAgent(Agent):
    """
    Your implementation of a reactive cleaner agent.
    """

    def response(self, perceptions):
        """
        TODO: your code here
        :param perceptions: The perceptions of the agent at each step
        :return: The `Action' that your agent takes after perceiving the environment at each step
        """
        return None

    def __str__(self):
        """
        :return: The 1-character representation of your agent name
        """
        return "1"


class MyAction(Action, Enum):
    """
    Actions for the cleaner agent.
    """

    # The robot must move forward
    FORWARD = 0

    # The robot must turn to the left.
    TURN_LEFT = 1

    # The robot must turn to the right.
    TURN_RIGHT = 2

    # The robot must clean the current tile.
    PICK = 3


class MyAgentPerception(Perception):
    """
    The perceptions of an agent.
    """

    def __init__(self, obstacle_orientations, jTile, orientation):
        """
        :param obstacle_orientations: Obstacles perceived. They are percieved as a relative orientation at which an
        obstacle is neighbor to the agent. The orientation is relative to the absolute orientation of the agent.

        :param jTile: True if there is trash in the current tile.
        :param orientation: The indication of the agent's compass.
        """

        self.obstacles = obstacle_orientations
        self.is_over_jtile = jTile
        self.absolute_orientation = orientation


class MyEnvironment(AbstractGridEnvironment):
    """
    Your implementation of the environment in which cleaner agents work.
    """

    def __init__(self):
        """
        Default constructor. This should call the initialize methods offered by the super class.
        """
        rand_seed = 42
        # rand_seed =  datetime.now()

        print("Seed = %i" % rand_seed)

        super(MyEnvironment, self).__init__()
        self.initialize(10, 10, 5, 5, rand_seed = rand_seed)


    def step(self):
        """
        This method should iterate through all agents, provide them provide them with perceptions, and apply the
        action they return.
        """

        for aData in self._agents:
            pass
            """
            TODO
            1. create agent perceptions
            2. get agent action based on perception
            3. implement agent action in environment
            """


class DummyAgent(Agent):
    """
    A simple agent that goes around in a circle and picks trash if it finds any.
    """
    def response(self, perceptions):
        print("Dummy agent sees current tile is %s; current orientation is %s; obstacles at: %s"
              % ("dirty" if perceptions.is_over_jtile else "clean",
                 str(perceptions.absolute_orientation),
                 str(perceptions.obstacles)))

        if perceptions.is_over_jtile:
            return MyAction.PICK

        if GridRelativeOrientation.FRONT in perceptions.obstacles:
            return MyAction.TURN_RIGHT

        return MyAction.FORWARD

    def __str__(self):
        return "D"



class Tester(object):

    DELAY = 0.1

    def __init__(self):
        self.env = MyEnvironment()

        agent_data = GridAgentData(DummyAgent(), self.env.get_bottom_left(), GridOrientation.NORTH)
        self.env.add_agent(agent_data)

        self.make_steps()

    def make_steps(self):
        while not self.env.goals_completed():
            self.env.step()

            print(self.env)

            time.sleep(Tester.DELAY)



if __name__ == "__main__":
    tester = Tester()
    tester.make_steps()

