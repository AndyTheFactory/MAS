package agents;

/**
 * Service types for discovered agents.
 */
public class ServiceType
{
	/**
	 * 
	 */
	public final static String ELECTION_MANAGEMENT = "election-management";
	
}
