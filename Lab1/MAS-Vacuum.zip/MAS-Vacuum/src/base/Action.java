package base;

/**
 * Interface to be implemented by classes representing actions.
 * 
 * @author Andrei Olaru
 */
public interface Action
{
	// nothing to specify, depends on environment
}
