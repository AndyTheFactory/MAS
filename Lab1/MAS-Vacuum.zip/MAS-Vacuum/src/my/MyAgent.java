package my;

import base.Action;
import base.Agent;
import base.Perceptions;

/**
 * Your implementation of a reactive cleaner agent.
 * 
 * @author Andrei Olaru
 */
public class MyAgent implements Agent
{
	@Override
	public Action response(Perceptions perceptions)
	{
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public String toString()
	{
		// TODO Auto-generated method stub
		// please use a single character
		return "1";
	}
	
}
